package com.app.testapp.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
public class SSLEcommerz {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
    @Column
    private String payslip_transId;
    @Column
    private double amount;
    @Column
    private String sessionKey;
    @Column
    private Integer paymentUpdateStatus;
    @Column
    private String merchantName;
    @Column
    private Integer institueId;
    @Column
    private String studentId;
    @Column
    private Date paymentRequestedDateTime;
    @Column
    private Date paymentUpdatedDateTime;
    public SSLEcommerz() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPayslip_transId() {
        return payslip_transId;
    }

    public void setPayslip_transId(String payslip_transId) {
        this.payslip_transId = payslip_transId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public Integer getPaymentUpdateStatus() {
        return paymentUpdateStatus;
    }

    public void setPaymentUpdateStatus(Integer paymentUpdateStatus) {
        this.paymentUpdateStatus = paymentUpdateStatus;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public Integer getInstitueId() {
        return institueId;
    }

    public void setInstitueId(Integer institueId) {
        this.institueId = institueId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public Date getPaymentRequestedDateTime() {
        return paymentRequestedDateTime;
    }

    public void setPaymentRequestedDateTime(Date paymentRequestedDateTime) {
        this.paymentRequestedDateTime = paymentRequestedDateTime;
    }

    public Date getPaymentUpdatedDateTime() {
        return paymentUpdatedDateTime;
    }

    public void setPaymentUpdatedDateTime(Date paymentUpdatedDateTime) {
        this.paymentUpdatedDateTime = paymentUpdatedDateTime;
    }
}
