package com.app.testapp.controller;

import com.app.testapp.controller.services.PaymentGatewayService;
import com.app.testapp.responseEntity.SSLInitiatePaymentResponse;
import com.app.testapp.responseEntity.ssldto.SSLCancelUrlDto;
import com.app.testapp.utils.SSLProcess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.LinkedList;

@Controller
public class HelloController {

    @Autowired
    PaymentGatewayService paymentGatewayService;

    @RequestMapping("/")
    public String init() {
        return "index";
    }

    @RequestMapping("/nagad")
    @ResponseBody
    public Object sayHello() throws Exception {

        String paymentGateWay = "Nagod";
        return paymentGatewayService.apiRequest(paymentGateWay);
    }

    @RequestMapping("/paymentresult")
    public void nagadPaymentResult(@RequestParam String merchant, @RequestParam String order_id,@RequestParam String payment_ref_id,@RequestParam String status,@RequestParam String status_code,@RequestParam String payment_dt,@RequestParam String issuer_payment_ref){

    }

    @RequestMapping("/ssl")
    @ResponseBody
    public Object sayHellotoSSL() throws Exception {

        return paymentGatewayService.sslApiRequest();

    }
    @RequestMapping(value = "/sslSuccess", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public Object sayHellotoSSLSuccess(@RequestParam MultiValueMap body) throws Exception {
//        String s= (String) ((LinkedList) (body.get("status"))).get(0);
        return body;

    }

    @RequestMapping(value = "/sslCancel", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public Object sayHellotoSSLCancel(@RequestParam MultiValueMap body) throws Exception {
        String s= (String) ((LinkedList) (body.get("status"))).get(0);
        return body;

    }
    @RequestMapping(value = "/sslFail", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public Object sayHellotoSSLFail(@RequestParam MultiValueMap body) throws Exception {

        return body;

    }

    @RequestMapping(value = "/sslIPNListener", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public Object sayHellotoSSLIPNListener(@RequestParam MultiValueMap body) throws Exception {

        return body;

    }

    @RequestMapping("/sslCheckTransaction")
    @ResponseBody
    public Object sayHellotoSSLCheckTransaction() throws Exception {

        return paymentGatewayService.sslCheckTransactionByTranId();

    }

    @RequestMapping("/sslCheckTransactionbySession")
    @ResponseBody
    public void sayHellotoSSLCheckTransactionbySession() throws Exception {

//        return paymentGatewayService.sslCheckTransactionBysessionkey();

    }





    @RequestMapping("/bKash")
    @ResponseBody
    public Object sayHellotoBkash() throws Exception {

        return paymentGatewayService.bkashApiRequest();
    }


}
