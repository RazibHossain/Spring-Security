package com.app.testapp.responseEntity;

import java.util.List;

public class SSLInitiatePaymentResponse {
    String status;
    String failedreason;
    String sessionkey;
    SSLGateways gw;
    String redirectGatewayURL;
    String directPaymentURLBank;
    String directPaymentURLCard;
    String directPaymentURL;
    String redirectGatewayURLFailed;
    String storeBanner;
    String storeLogo;
    String store_name;
    List<GatewaysDetailsInformation> desc;
    String is_direct_pay_enable;
    String GatewayPageURL;

    public SSLInitiatePaymentResponse() {
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFailedreason() {
        return failedreason;
    }

    public void setFailedreason(String failedreason) {
        this.failedreason = failedreason;
    }

    public String getSessionkey() {
        return sessionkey;
    }

    public void setSessionkey(String sessionkey) {
        this.sessionkey = sessionkey;
    }

    public SSLGateways getGw() {
        return gw;
    }

    public void setGw(SSLGateways gw) {
        this.gw = gw;
    }

    public String getRedirectGatewayURL() {
        return redirectGatewayURL;
    }

    public void setRedirectGatewayURL(String redirectGatewayURL) {
        this.redirectGatewayURL = redirectGatewayURL;
    }

    public String getDirectPaymentURLBank() {
        return directPaymentURLBank;
    }

    public void setDirectPaymentURLBank(String directPaymentURLBank) {
        this.directPaymentURLBank = directPaymentURLBank;
    }

    public String getDirectPaymentURLCard() {
        return directPaymentURLCard;
    }

    public void setDirectPaymentURLCard(String directPaymentURLCard) {
        this.directPaymentURLCard = directPaymentURLCard;
    }

    public String getDirectPaymentURL() {
        return directPaymentURL;
    }

    public void setDirectPaymentURL(String directPaymentURL) {
        this.directPaymentURL = directPaymentURL;
    }

    public String getRedirectGatewayURLFailed() {
        return redirectGatewayURLFailed;
    }

    public void setRedirectGatewayURLFailed(String redirectGatewayURLFailed) {
        this.redirectGatewayURLFailed = redirectGatewayURLFailed;
    }

    public String getGatewayPageURL() {
        return GatewayPageURL;
    }

    public void setGatewayPageURL(String gatewayPageURL) {
        GatewayPageURL = gatewayPageURL;
    }

    public String getStoreBanner() {
        return storeBanner;
    }

    public void setStoreBanner(String storeBanner) {
        this.storeBanner = storeBanner;
    }

    public String getStoreLogo() {
        return storeLogo;
    }

    public void setStoreLogo(String storeLogo) {
        this.storeLogo = storeLogo;
    }

    public String getStore_name() {
        return store_name;
    }

    public void setStore_name(String store_name) {
        this.store_name = store_name;
    }

    public List<GatewaysDetailsInformation> getDesc() {
        return desc;
    }

    public void setDesc(List<GatewaysDetailsInformation> desc) {
        this.desc = desc;
    }

    public String getIs_direct_pay_enable() {
        return is_direct_pay_enable;
    }

    public void setIs_direct_pay_enable(String is_direct_pay_enable) {
        this.is_direct_pay_enable = is_direct_pay_enable;
    }
}