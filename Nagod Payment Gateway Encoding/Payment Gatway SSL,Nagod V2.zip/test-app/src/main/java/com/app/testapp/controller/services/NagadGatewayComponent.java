package com.app.testapp.controller.services;

import com.app.testapp.utils.NagadProcessBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
public class NagadGatewayComponent {
    @Value("${nagad.baseUrl}")
    private String nagadBaseUrl;
    @Value("${publicKey.filePath}")
    private String publicKeyFilepath;
    @Value("${privateKey.filePath}")
    private String privateKeyFilepath;
    @Value("${merchant.callBackUrl}")
    private String merchantCallBackUrl;
    @Value("${merchant.ipv4}")
    private String merchantipv4;

    @Bean
    NagadProcessBuilder getNagadProcessBuilder(){
        return new NagadProcessBuilder()
                .setNagadBaseURL(nagadBaseUrl)
                .setMarchentID("683002007104225")
//                .setPublicKeyFilePath("C:\\Users\\Dell\\Downloads\\test-app\\src\\main\\java\\com\\app\\testapp\\pgPublicKey.txt")
                .setPublicKeyFilePath(publicKeyFilepath)
//                .setPrivateKeyFilePath("C:\\Users\\Dell\\Downloads\\test-app\\src\\main\\java\\com\\app\\testapp\\merchantPrivateKey.txt")
                .setPrivateKeyFilePath(privateKeyFilepath)
                .setCurrencyCode("050")
                .setMarchentCallbackUrl(merchantCallBackUrl)
                .setMarchentAccountNo("01684283696")
                .setIpV4(merchantipv4)
//                .setIpV4("192.168.107.151")
                .setClientType("PC_WEB")
                .setContentType("application/json")
                .setApiVersion("v-0.2.0");
    }
}
