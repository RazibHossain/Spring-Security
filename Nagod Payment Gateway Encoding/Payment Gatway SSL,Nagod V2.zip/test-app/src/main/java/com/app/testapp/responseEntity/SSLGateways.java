package com.app.testapp.responseEntity;

public class SSLGateways {
    String visa;
    String master;
    String amex;
    String othercards;
    String internetbanking;
    String mobilebanking;

    public SSLGateways() {
    }

    public SSLGateways(String visa, String master, String amex, String othercards, String internetbanking, String mobilebanking) {
        this.visa = visa;
        this.master = master;
        this.amex = amex;
        this.othercards = othercards;
        this.internetbanking = internetbanking;
        this.mobilebanking = mobilebanking;
    }

    public String getVisa() {
        return visa;
    }

    public void setVisa(String visa) {
        this.visa = visa;
    }

    public String getMaster() {
        return master;
    }

    public void setMaster(String master) {
        this.master = master;
    }

    public String getAmex() {
        return amex;
    }

    public void setAmex(String amex) {
        this.amex = amex;
    }

    public String getOthercards() {
        return othercards;
    }

    public void setOthercards(String othercards) {
        this.othercards = othercards;
    }

    public String getInternetbanking() {
        return internetbanking;
    }

    public void setInternetbanking(String internetbanking) {
        this.internetbanking = internetbanking;
    }

    public String getMobilebanking() {
        return mobilebanking;
    }

    public void setMobilebanking(String mobilebanking) {
        this.mobilebanking = mobilebanking;
    }
}
