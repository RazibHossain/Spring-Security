package com.app.testapp.responseEntity;

public class GatewaysDetailsInformation {

    String name;
    String type;
    String logo;
    String gw;
    String r_flag;
    String redirectGatewayURL;

    public GatewaysDetailsInformation() {
    }

    public GatewaysDetailsInformation(String name, String type, String logo, String gw, String r_flag, String redirectGatewayURL) {
        this.name = name;
        this.type = type;
        this.logo = logo;
        this.gw = gw;
        this.r_flag = r_flag;
        this.redirectGatewayURL = redirectGatewayURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getGw() {
        return gw;
    }

    public void setGw(String gw) {
        this.gw = gw;
    }

    public String getR_flag() {
        return r_flag;
    }

    public void setR_flag(String r_flag) {
        this.r_flag = r_flag;
    }

    public String getRedirectGatewayURL() {
        return redirectGatewayURL;
    }

    public void setRedirectGatewayURL(String redirectGatewayURL) {
        this.redirectGatewayURL = redirectGatewayURL;
    }
}
