package com.app.testapp.responseEntity;

public class NagodOrderRequestResponse {

    String sensitiveData;
    String signature;

    public NagodOrderRequestResponse() {
    }

    public NagodOrderRequestResponse(String sensitiveData, String signature) {
        this.sensitiveData = sensitiveData;
        this.signature = signature;
    }

    public String getSensitiveData() {
        return sensitiveData;
    }

    public void setSensitiveData(String sensitiveData) {
        this.sensitiveData = sensitiveData;
    }

    public String getSignature() {
        return signature;
    }


    public void setSignature(String signature) {
        this.signature = signature;
    }
}
