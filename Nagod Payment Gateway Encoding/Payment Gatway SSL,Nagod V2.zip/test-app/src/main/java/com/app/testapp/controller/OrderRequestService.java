package com.app.testapp.controller;

import org.springframework.stereotype.Service;

@Service
public class OrderRequestService {

    public Object getOrderRequest(){



        return null;
    }
}
