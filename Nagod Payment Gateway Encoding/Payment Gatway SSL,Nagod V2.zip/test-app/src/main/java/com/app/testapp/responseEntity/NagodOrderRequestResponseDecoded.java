package com.app.testapp.responseEntity;

public class NagodOrderRequestResponseDecoded {
    String paymentReferenceId;
    String acceptDateTime;
    String challenge;

    public NagodOrderRequestResponseDecoded() {

    }

    public NagodOrderRequestResponseDecoded(String paymentReferenceId, String acceptDateTime, String challenge) {
        this.paymentReferenceId = paymentReferenceId;
        this.acceptDateTime = acceptDateTime;
        this.challenge = challenge;
    }

    public String getPaymentReferenceId() {
        return paymentReferenceId;
    }

    public void setPaymentReferenceId(String paymentReferenceId) {
        this.paymentReferenceId = paymentReferenceId;
    }

    public String getAcceptDateTime() {
        return acceptDateTime;
    }

    public void setAcceptDateTime(String acceptDateTime) {
        this.acceptDateTime = acceptDateTime;
    }

    public String getChallenge() {
        return challenge;
    }

    public void setChallenge(String challenge) {
        this.challenge = challenge;
    }
}
