package com.app.testapp.utils;

import com.app.testapp.responseEntity.CallbackResponseEntity;
import com.app.testapp.responseEntity.NagodOrderRequestResponse;
import com.app.testapp.responseEntity.NagodOrderRequestResponseDecoded;
import com.google.gson.Gson;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import com.app.testapp.utils.NagadURIs;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class NagadUtil {

    public NagodOrderRequestResponse nagadInitilizeRequest(String publicKeyFilePath, String privateKeyFilePath,String currentDateTime,
                                                           String merchantId,String orderId, String merchantChallenge,String ipv4, String clientType,
                                                           String apiVersion,String merchantAccountNumber,String nagadBaseUrl

                                                           ) throws Exception {

        RSA rsa = new RSA();
//        NagadURIs nagadURIs = new NagadURIs();
//        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
//        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//        String currentTime = sdf1.format(timestamp).toString();


        String sensitiveInformation = "{\n" +
                "  \"merchantId\": \""+merchantId+"\",\n" +
                "  \"datetime\": \""+currentDateTime+"\",\n" +
                "  \"orderId\": \""+orderId+"\",\n" +
                "  \"challenge\":\""+merchantChallenge+"\"\n" +
                "}";


        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("X-KM-IP-V4",ipv4);
        headers.add("X-KM-Client-Type",clientType);
        headers.add("X-KM-Api-Version",apiVersion);

//        String accountNumber = "01684283696";
//        String datetime = currentDateTime;
        String sensitiveData = rsa.getEncodedByPublicKeyAndRSAWithPKCS1Padding(sensitiveInformation,publicKeyFilePath);
        String signature = rsa.getDigitalSignatureBySHA256WithRSA(sensitiveInformation,privateKeyFilePath);

        String requestBody = "{\n" +
                "  \"accountNumber\": \""+ merchantAccountNumber +"\",\n" +
                "  \"datetime\": \""+currentDateTime+"\",\n" +
                "  \"sensitiveData\": \""+sensitiveData+"\",\n" +
                "  \"signature\":\""+signature+"\"\n" +
                "}";
        String initializeUrl = NagadURIs.INITIALIZE_URL.getUri();
        String url = nagadBaseUrl + initializeUrl + merchantId+"/"+orderId;

        HttpEntity<String> request = new HttpEntity<String>(requestBody, headers);
        
        ResponseEntity<NagodOrderRequestResponse> responseEntity = restTemplate.postForEntity(url, request, NagodOrderRequestResponse.class);
        NagodOrderRequestResponse nagodOrderRequestResponse = responseEntity.getBody();
        return nagodOrderRequestResponse;
    }

    public boolean verifySignature(String signature, String publicKeyFilePath, String receivedSensitiveData, String privateKeyFilePath) throws Exception {
        RSA rsa = new RSA();
        return rsa.verifyDigitalSignatureBySHA256WithRSA(signature,publicKeyFilePath,receivedSensitiveData,privateKeyFilePath);
    }

    public NagodOrderRequestResponseDecoded  decodeSensitiveData(String sensitiveData, String privateKeyFilePath) throws Exception {
        RSA rsa = new RSA();

        String decodedValue =  rsa.getDecodedByPrivateKeyAndRSAWithPKCS1Padding(sensitiveData,privateKeyFilePath);
        Gson gson = new Gson();
        NagodOrderRequestResponseDecoded nagodOrderRequestResponseDecoded = gson.fromJson(decodedValue, NagodOrderRequestResponseDecoded.class);
        return nagodOrderRequestResponseDecoded;
    }

    public CallbackResponseEntity getCallBackUrl(String merchantId, String orderId, String amount, String currencyCode,
                                                 String receiveChallenge, String merchantCallbackUrl, String nagadBaseUrl, String ipv4,String clientType, String apiVersion,
                                                 String paymentReferenceId, String publicKeyFilePath, String privateKeyFilePath) throws Exception {
        RSA rsa = new RSA();

        String secretMessage = "{\n" +
                "  \"merchantId\": \""+merchantId+"\",\n" +
                "  \"orderId\": \""+orderId+"\",\n" +
                "  \"amount\": \""+amount+"\",\n" +
                "  \"currencyCode\": \""+currencyCode+"\",\n" +
                "  \"challenge\": \""+receiveChallenge+"\"\n" +
                "}";

        String sensitiveData = rsa.getEncodedByPublicKeyAndRSAWithPKCS1Padding(secretMessage, publicKeyFilePath);
        String signature = rsa.getDigitalSignatureBySHA256WithRSA(secretMessage, privateKeyFilePath);

        String requestBody = "{\n" +
                "    \"sensitiveData\": \""+sensitiveData+"\",\n" +
                "    \"signature\": \""+signature+"\",\n" +
                "    \"merchantCallbackURL\": \""+merchantCallbackUrl+"\",\n" +
                "    \"additionalMerchantInfo\": {\n" +
                "        \"fees\": \"Tution\",\n" +
                "        \"onlinePay\": \"Yes\"\n" +
                "    }\n" +
                "}";
        String orderUrl = NagadURIs.ORDER_URL.getUri();
        String url = nagadBaseUrl+orderUrl +paymentReferenceId;

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("X-KM-IP-V4",ipv4);
        headers.add("X-KM-Client-Type",clientType);
        headers.add("X-KM-Api-Version",apiVersion);

        HttpEntity<String> request = new HttpEntity<String>(requestBody, headers);

        ResponseEntity<CallbackResponseEntity> responseEntity = restTemplate.postForEntity(url, request, CallbackResponseEntity.class);
        CallbackResponseEntity callbackResponseEntity = responseEntity.getBody();

        return callbackResponseEntity;
    }
}
