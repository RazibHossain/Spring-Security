package com.app.testapp.controller.services;

import com.app.testapp.entity.SSLEcommerz;
import com.app.testapp.repository.SSLEcommerzRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class SSLPaymentUpdateScheduler {
    @Autowired
    SSLEcommerzRepository sslEcommerzRepository;
    @Autowired
    PaymentGatewayService paymentGatewayService;
    @Scheduled(cron = "0 0/1 * * * *")
    public void cronJobSch() {

//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date dateToday = new Date();
//        String strDate = sdf.format(now);
// 1 day = 86400000ms
        Date dateThreeDaysBefore = new Date(new Date().getTime() - (86400000*3));


        List<SSLEcommerz> sslEcommerzList= sslEcommerzRepository.getValueByDate(dateThreeDaysBefore,dateToday);


        paymentGatewayService.sslCheckTransactionBysessionkey(sslEcommerzList);
        System.out.println("Java cron job expression:: " + 1);
    }


}
