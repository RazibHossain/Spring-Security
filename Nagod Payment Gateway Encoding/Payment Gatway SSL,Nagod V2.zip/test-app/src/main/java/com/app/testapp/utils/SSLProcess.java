package com.app.testapp.utils;

import com.app.testapp.responseEntity.SSLInitiatePaymentResponse;

public class SSLProcess {
    String sslBaseUrl;

    String store_id;
    String store_passwd;
    String total_amount;
    String currency;
    String tran_id;
    String success_url;
    String fail_url;
    String cancel_url;
    String ipn_url;
    String multi_card_name;
    String allowed_bin;
    String emi_option;
    String emi_max_inst_option;
    String emi_selected_inst;
    String emi_allow_only;
    String cus_name;
    String cus_email;
    String cus_add1;
    String cus_add2;
    String cus_city;
    String cus_state;
    String cus_postcode;
    String cus_country;
    String cus_phone;
    String cus_fax;
    String shipping_method;
    String num_of_item;
    String ship_name;
    String ship_add1;
    String ship_add2;
    String ship_city;
    String ship_state;
    String ship_postcode;
    String ship_country;
    String product_name;
    String product_category;
    String product_profile;
    String hours_till_departure;
    String flight_type;
    String pnr;
    String journey_from_to;
    String third_party_booking;
    String hotel_name;
    String length_of_stay;
    String check_in_time;
    String hotel_city;
    String product_type;
    String topup_number;
    String country_topup;
    String cart;
    String product_amount;
    String vat;
    String discount_amount;
    String convenience_fee;
    String value_a;
    String value_b;
    String value_c;
    String value_d;
    String gateWayUrl;
    SSLEcommerzUtil sslEcommerzUtil;



    public SSLInitiatePaymentResponse getSslInitiatePaymentResponse() {
        return sslInitiatePaymentResponse;
    }

    public void setSslInitiatePaymentResponse(SSLInitiatePaymentResponse sslInitiatePaymentResponse) {
        this.sslInitiatePaymentResponse = sslInitiatePaymentResponse;
    }

    SSLInitiatePaymentResponse sslInitiatePaymentResponse;
    public SSLProcess() {
        this.sslEcommerzUtil = new SSLEcommerzUtil();
    }

    public String getSslBaseUrl() {
        return sslBaseUrl;
    }

    public void setSslBaseUrl(String sslBaseUrl) {
        this.sslBaseUrl = sslBaseUrl;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getStore_passwd() {
        return store_passwd;
    }

    public void setStore_passwd(String store_passwd) {
        this.store_passwd = store_passwd;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTran_id() {
        return tran_id;
    }

    public void setTran_id(String tran_id) {
        this.tran_id = tran_id;
    }

    public String getSuccess_url() {
        return success_url;
    }

    public void setSuccess_url(String success_url) {
        this.success_url = success_url;
    }

    public String getFail_url() {
        return fail_url;
    }

    public void setFail_url(String fail_url) {
        this.fail_url = fail_url;
    }

    public String getCancel_url() {
        return cancel_url;
    }

    public void setCancel_url(String cancel_url) {
        this.cancel_url = cancel_url;
    }

    public String getIpn_url() {
        return ipn_url;
    }

    public void setIpn_url(String ipn_url) {
        this.ipn_url = ipn_url;
    }

    public String getMulti_card_name() {
        return multi_card_name;
    }

    public void setMulti_card_name(String multi_card_name) {
        this.multi_card_name = multi_card_name;
    }

    public String getAllowed_bin() {
        return allowed_bin;
    }

    public void setAllowed_bin(String allowed_bin) {
        this.allowed_bin = allowed_bin;
    }

    public String getEmi_option() {
        return emi_option;
    }

    public void setEmi_option(String emi_option) {
        this.emi_option = emi_option;
    }

    public String getEmi_max_inst_option() {
        return emi_max_inst_option;
    }

    public void setEmi_max_inst_option(String emi_max_inst_option) {
        this.emi_max_inst_option = emi_max_inst_option;
    }

    public String getEmi_selected_inst() {
        return emi_selected_inst;
    }

    public void setEmi_selected_inst(String emi_selected_inst) {
        this.emi_selected_inst = emi_selected_inst;
    }

    public String getEmi_allow_only() {
        return emi_allow_only;
    }

    public void setEmi_allow_only(String emi_allow_only) {
        this.emi_allow_only = emi_allow_only;
    }

    public String getCus_name() {
        return cus_name;
    }

    public void setCus_name(String cus_name) {
        this.cus_name = cus_name;
    }

    public String getCus_email() {
        return cus_email;
    }

    public void setCus_email(String cus_email) {
        this.cus_email = cus_email;
    }

    public String getCus_add1() {
        return cus_add1;
    }

    public void setCus_add1(String cus_add1) {
        this.cus_add1 = cus_add1;
    }

    public String getCus_add2() {
        return cus_add2;
    }

    public void setCus_add2(String cus_add2) {
        this.cus_add2 = cus_add2;
    }

    public String getCus_city() {
        return cus_city;
    }

    public void setCus_city(String cus_city) {
        this.cus_city = cus_city;
    }

    public String getCus_state() {
        return cus_state;
    }

    public void setCus_state(String cus_state) {
        this.cus_state = cus_state;
    }

    public String getCus_postcode() {
        return cus_postcode;
    }

    public void setCus_postcode(String cus_postcode) {
        this.cus_postcode = cus_postcode;
    }

    public String getCus_country() {
        return cus_country;
    }

    public void setCus_country(String cus_country) {
        this.cus_country = cus_country;
    }

    public String getCus_phone() {
        return cus_phone;
    }

    public void setCus_phone(String cus_phone) {
        this.cus_phone = cus_phone;
    }

    public String getCus_fax() {
        return cus_fax;
    }

    public void setCus_fax(String cus_fax) {
        this.cus_fax = cus_fax;
    }

    public String getShipping_method() {
        return shipping_method;
    }

    public void setShipping_method(String shipping_method) {
        this.shipping_method = shipping_method;
    }

    public String getNum_of_item() {
        return num_of_item;
    }

    public void setNum_of_item(String num_of_item) {
        this.num_of_item = num_of_item;
    }

    public String getShip_name() {
        return ship_name;
    }

    public void setShip_name(String ship_name) {
        this.ship_name = ship_name;
    }

    public String getShip_add1() {
        return ship_add1;
    }

    public void setShip_add1(String ship_add1) {
        this.ship_add1 = ship_add1;
    }

    public String getShip_add2() {
        return ship_add2;
    }

    public void setShip_add2(String ship_add2) {
        this.ship_add2 = ship_add2;
    }

    public String getShip_city() {
        return ship_city;
    }

    public void setShip_city(String ship_city) {
        this.ship_city = ship_city;
    }

    public String getShip_state() {
        return ship_state;
    }

    public void setShip_state(String ship_state) {
        this.ship_state = ship_state;
    }

    public String getShip_postcode() {
        return ship_postcode;
    }

    public void setShip_postcode(String ship_postcode) {
        this.ship_postcode = ship_postcode;
    }

    public String getShip_country() {
        return ship_country;
    }

    public void setShip_country(String ship_country) {
        this.ship_country = ship_country;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_category() {
        return product_category;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    public String getProduct_profile() {
        return product_profile;
    }

    public void setProduct_profile(String product_profile) {
        this.product_profile = product_profile;
    }

    public String getHours_till_departure() {
        return hours_till_departure;
    }

    public void setHours_till_departure(String hours_till_departure) {
        this.hours_till_departure = hours_till_departure;
    }

    public String getFlight_type() {
        return flight_type;
    }

    public void setFlight_type(String flight_type) {
        this.flight_type = flight_type;
    }

    public String getPnr() {
        return pnr;
    }

    public void setPnr(String pnr) {
        this.pnr = pnr;
    }

    public String getJourney_from_to() {
        return journey_from_to;
    }

    public void setJourney_from_to(String journey_from_to) {
        this.journey_from_to = journey_from_to;
    }

    public String getThird_party_booking() {
        return third_party_booking;
    }

    public void setThird_party_booking(String third_party_booking) {
        this.third_party_booking = third_party_booking;
    }

    public String getHotel_name() {
        return hotel_name;
    }

    public void setHotel_name(String hotel_name) {
        this.hotel_name = hotel_name;
    }

    public String getLength_of_stay() {
        return length_of_stay;
    }

    public void setLength_of_stay(String length_of_stay) {
        this.length_of_stay = length_of_stay;
    }

    public String getCheck_in_time() {
        return check_in_time;
    }

    public void setCheck_in_time(String check_in_time) {
        this.check_in_time = check_in_time;
    }

    public String getHotel_city() {
        return hotel_city;
    }

    public void setHotel_city(String hotel_city) {
        this.hotel_city = hotel_city;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }

    public String getTopup_number() {
        return topup_number;
    }

    public void setTopup_number(String topup_number) {
        this.topup_number = topup_number;
    }

    public String getCountry_topup() {
        return country_topup;
    }

    public void setCountry_topup(String country_topup) {
        this.country_topup = country_topup;
    }

    public String getCart() {
        return cart;
    }

    public void setCart(String cart) {
        this.cart = cart;
    }

    public String getProduct_amount() {
        return product_amount;
    }

    public void setProduct_amount(String product_amount) {
        this.product_amount = product_amount;
    }

    public String getVat() {
        return vat;
    }

    public void setVat(String vat) {
        this.vat = vat;
    }

    public String getDiscount_amount() {
        return discount_amount;
    }

    public void setDiscount_amount(String discount_amount) {
        this.discount_amount = discount_amount;
    }

    public String getConvenience_fee() {
        return convenience_fee;
    }

    public void setConvenience_fee(String convenience_fee) {
        this.convenience_fee = convenience_fee;
    }

    public String getValue_a() {
        return value_a;
    }

    public void setValue_a(String value_a) {
        this.value_a = value_a;
    }

    public String getValue_b() {
        return value_b;
    }

    public void setValue_b(String value_b) {
        this.value_b = value_b;
    }

    public String getValue_c() {
        return value_c;
    }

    public void setValue_c(String value_c) {
        this.value_c = value_c;
    }

    public String getValue_d() {
        return value_d;
    }

    public void setValue_d(String value_d) {
        this.value_d = value_d;
    }

    public String getGateWayUrl() {
        return gateWayUrl;
    }

    public void setGateWayUrl(String gateWayUrl) {
        this.gateWayUrl = gateWayUrl;
    }

    public SSLProcess initialize() {
        this.sslInitiatePaymentResponse = sslEcommerzUtil.requestForSessionId(this);
        return this;
    }
}
