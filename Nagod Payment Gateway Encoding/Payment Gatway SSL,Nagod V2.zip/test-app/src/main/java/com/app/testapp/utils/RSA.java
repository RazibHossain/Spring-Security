package com.app.testapp.utils;
import javax.crypto.Cipher;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.security.spec.EncodedKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Base64;

public class RSA {

    public static PublicKey getPublicKey(String publicKeyFilePath) throws Exception{
        File publicKeyFile = new File(publicKeyFilePath);
        byte[] publicKeyBytes = Files.readAllBytes(publicKeyFile.toPath());
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyBytes));
        PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
        return publicKey;
    }
    private static PrivateKey getPrivateKey(String privateKeyFilePath) throws Exception{
        File privateKeyFile = new File(privateKeyFilePath);
        byte[] privateKeyBytes = Files.readAllBytes(privateKeyFile.toPath());
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyBytes));

        PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);

        return privateKey;
    }

     String getEncodedByPublicKeyAndRSAWithPKCS1Padding(String secretMessage, String publicKeyFilePath) throws Exception{

        PublicKey publicKey = getPublicKey(publicKeyFilePath);

        Cipher encryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);

        byte[] secretMessageBytes = secretMessage.getBytes(StandardCharsets.UTF_8);
        byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);

        String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);

        return encodedMessage;
    }

     String getDecodedByPrivateKeyAndRSAWithPKCS1Padding(String secretMessage, String privateKeyFilePath) throws Exception{

        PrivateKey privateKey = getPrivateKey(privateKeyFilePath);

        Cipher decryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        decryptCipher.init(Cipher.DECRYPT_MODE, privateKey);

        byte[] secretMessageBytes = Base64.getDecoder().decode(secretMessage.getBytes(StandardCharsets.UTF_8));
        byte[] decryptedMessageBytes = decryptCipher.doFinal(secretMessageBytes);

        String decodedMessage = new String(decryptedMessageBytes);

        return decodedMessage;
    }




    public  String getDigitalSignatureBySHA256WithRSA(String secretMessage, String privateKeyFilePath) throws Exception{

        PrivateKey privateKey = getPrivateKey(privateKeyFilePath);


        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initSign(privateKey);
        privateSignature.update(secretMessage.getBytes(StandardCharsets.UTF_8));
        byte[] s = privateSignature.sign();

        return Base64.getEncoder().encodeToString(s);

    }

    public  boolean verifyDigitalSignatureBySHA256WithRSA(String signature, String publicKeyFilePath, String receivedMessage, String privateKeyFilePath ) throws Exception{
        PublicKey publicKey = getPublicKey(publicKeyFilePath);

        Signature publicSignature = Signature.getInstance("SHA256withRSA");
        publicSignature.initVerify(publicKey);
        publicSignature.update(getDecodedByPrivateKeyAndRSAWithPKCS1Padding(receivedMessage, privateKeyFilePath).getBytes());
        return publicSignature.verify(Base64.getDecoder().decode(signature.getBytes(StandardCharsets.UTF_8)));

    }
}
