package com.app.testapp.repository;

import com.app.testapp.entity.SSLEcommerz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface SSLEcommerzRepository extends JpaRepository<SSLEcommerz,Integer> {



    @Query(value = "select *\n" +
            "from sslecommerz\n" +
            "where payment_update_status = 0\n" +
            "and payment_requested_date_time>=?1\n" +
            "and payment_requested_date_time<=?2",nativeQuery = true)

    public List<SSLEcommerz>  getValueByDate(Date threeDaysbefore, Date currentDate);

    @Modifying
    @Transactional
    @Query(value = "update sslecommerz\n" +
            "set payment_update_status =1, payment_updated_date_time = ?1\n" +
            "where session_key =?2",nativeQuery = true)

    public void updatePaymentStatus(Date updatedTime, String sessionKey);


}
