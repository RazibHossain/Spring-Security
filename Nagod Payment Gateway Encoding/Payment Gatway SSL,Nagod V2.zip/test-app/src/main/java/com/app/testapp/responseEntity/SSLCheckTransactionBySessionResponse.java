package com.app.testapp.responseEntity;

public class SSLCheckTransactionBySessionResponse {
    String status;
    String sessionKey;
    String tran_date;
    String tran_id;
    String val_id;
    String amount;
    String store_amount;
    String bank_tran_id;
    String card_type;
    String card_no;
    String card_issuer;
    String card_brand;
    String card_issuer_country;
    String card_issuer_country_code;
    String currency_type;
    String currency_amount;
    String currency_rate;
    String base_fair;
    String value_a;
    String value_b;
    String value_c;
    String value_d;
    String risk_title;
    String risk_level;
    String APIConnect;
    String validated_on;
    String gw_version;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public String getTran_date() {
        return tran_date;
    }

    public void setTran_date(String tran_date) {
        this.tran_date = tran_date;
    }

    public String getTran_id() {
        return tran_id;
    }

    public void setTran_id(String tran_id) {
        this.tran_id = tran_id;
    }

    public String getVal_id() {
        return val_id;
    }

    public void setVal_id(String val_id) {
        this.val_id = val_id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStore_amount() {
        return store_amount;
    }

    public void setStore_amount(String store_amount) {
        this.store_amount = store_amount;
    }

    public String getBank_tran_id() {
        return bank_tran_id;
    }

    public void setBank_tran_id(String bank_tran_id) {
        this.bank_tran_id = bank_tran_id;
    }

    public String getCard_type() {
        return card_type;
    }

    public void setCard_type(String card_type) {
        this.card_type = card_type;
    }

    public String getCard_no() {
        return card_no;
    }

    public void setCard_no(String card_no) {
        this.card_no = card_no;
    }

    public String getCard_issuer() {
        return card_issuer;
    }

    public void setCard_issuer(String card_issuer) {
        this.card_issuer = card_issuer;
    }

    public String getCard_brand() {
        return card_brand;
    }

    public void setCard_brand(String card_brand) {
        this.card_brand = card_brand;
    }

    public String getCard_issuer_country() {
        return card_issuer_country;
    }

    public void setCard_issuer_country(String card_issuer_country) {
        this.card_issuer_country = card_issuer_country;
    }

    public String getCard_issuer_country_code() {
        return card_issuer_country_code;
    }

    public void setCard_issuer_country_code(String card_issuer_country_code) {
        this.card_issuer_country_code = card_issuer_country_code;
    }

    public String getCurrency_type() {
        return currency_type;
    }

    public void setCurrency_type(String currency_type) {
        this.currency_type = currency_type;
    }

    public String getCurrency_amount() {
        return currency_amount;
    }

    public void setCurrency_amount(String currency_amount) {
        this.currency_amount = currency_amount;
    }

    public String getCurrency_rate() {
        return currency_rate;
    }

    public void setCurrency_rate(String currency_rate) {
        this.currency_rate = currency_rate;
    }

    public String getBase_fair() {
        return base_fair;
    }

    public void setBase_fair(String base_fair) {
        this.base_fair = base_fair;
    }

    public String getValue_a() {
        return value_a;
    }

    public void setValue_a(String value_a) {
        this.value_a = value_a;
    }

    public String getValue_b() {
        return value_b;
    }

    public void setValue_b(String value_b) {
        this.value_b = value_b;
    }

    public String getValue_c() {
        return value_c;
    }

    public void setValue_c(String value_c) {
        this.value_c = value_c;
    }

    public String getValue_d() {
        return value_d;
    }

    public void setValue_d(String value_d) {
        this.value_d = value_d;
    }

    public String getRisk_title() {
        return risk_title;
    }

    public void setRisk_title(String risk_title) {
        this.risk_title = risk_title;
    }

    public String getRisk_level() {
        return risk_level;
    }

    public void setRisk_level(String risk_level) {
        this.risk_level = risk_level;
    }

    public String getAPIConnect() {
        return APIConnect;
    }

    public void setAPIConnect(String APIConnect) {
        this.APIConnect = APIConnect;
    }

    public String getValidated_on() {
        return validated_on;
    }

    public void setValidated_on(String validated_on) {
        this.validated_on = validated_on;
    }

    public String getGw_version() {
        return gw_version;
    }

    public void setGw_version(String gw_version) {
        this.gw_version = gw_version;
    }
}
