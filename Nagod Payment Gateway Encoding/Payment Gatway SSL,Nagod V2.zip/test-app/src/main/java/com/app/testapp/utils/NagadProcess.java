package com.app.testapp.utils;

import com.app.testapp.responseEntity.CallbackResponseEntity;
import com.app.testapp.responseEntity.NagodOrderRequestResponse;
import com.app.testapp.responseEntity.NagodOrderRequestResponseDecoded;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class NagadProcess {

    String nagadBaseURL;
    String marchentCallbackUrl;
    String nagadCallbackUrl;
    String marchentID;
    String publicKeyFilePath;
    String privateKeyFilePath;
    String receivedSensitiveData;
    String nagadSignature;
    String sendingSensitiveData;
    String ownSignature;
    String orderNo;
    String sendingChallangeNO;
    String receivedChallangeNO;
    String paymentReferanceID;
    String amount;
    String currentTime;
    String currencyCode;
    String marchentAccountNo;
    String ipV4;
    String apiVersion;
    String contentType;
    String clientType;
    boolean isVerifiedSignature;
    NagodOrderRequestResponse nagodOrderRequestResponse;
    NagodOrderRequestResponseDecoded nagodOrderRequestResponseDecoded;
    CallbackResponseEntity callbackResponseEntity;
    String paymentStatus;

    NagadUtil nagadUtil;

    public NagadProcess(){
        this.nagadUtil = new NagadUtil();
    }

    public String getIpV4() {
        return ipV4;
    }

    public void setIpV4(String ipV4) {
        this.ipV4 = ipV4;
    }

    public NagodOrderRequestResponse getNagodOrderRequestResponse() {
        return nagodOrderRequestResponse;
    }

    public void setNagodOrderRequestResponse(NagodOrderRequestResponse nagodOrderRequestResponse) {
        this.nagodOrderRequestResponse = nagodOrderRequestResponse;
    }

    public NagodOrderRequestResponseDecoded getNagodOrderRequestResponseDecoded() {
        return nagodOrderRequestResponseDecoded;
    }

    public void setNagodOrderRequestResponseDecoded(NagodOrderRequestResponseDecoded nagodOrderRequestResponseDecoded) {
        this.nagodOrderRequestResponseDecoded = nagodOrderRequestResponseDecoded;
    }

    public CallbackResponseEntity getCallbackResponseEntity() {
        return callbackResponseEntity;
    }

    public void setCallbackResponseEntity(CallbackResponseEntity callbackResponseEntity) {
        this.callbackResponseEntity = callbackResponseEntity;
    }

    public String getApiVersion() {
        return apiVersion;
    }

    public void setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public String getMarchentAccountNo() {
        return marchentAccountNo;
    }

    public void setMarchentAccountNo(String marchentAccountNo) {
        this.marchentAccountNo = marchentAccountNo;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getNagadBaseURL() {
        return nagadBaseURL;
    }

    public void setNagadBaseURL(String nagadBaseURL) {
        this.nagadBaseURL = nagadBaseURL;
    }

    public String getMarchentCallbackUrl() {
        return marchentCallbackUrl;
    }

    public void setMarchentCallbackUrl(String marchentCallbackUrl) {
        this.marchentCallbackUrl = marchentCallbackUrl;
    }

    public String getNagadCallbackUrl() {
        return nagadCallbackUrl;
    }

    public void setNagadCallbackUrl(String nagadCallbackUrl) {
        this.nagadCallbackUrl = nagadCallbackUrl;
    }

    public String getMarchentID() {
        return marchentID;
    }

    public void setMarchentID(String marchentID) {
        this.marchentID = marchentID;
    }

    public String getPublicKeyFilePath() {
        return publicKeyFilePath;
    }

    public void setPublicKeyFilePath(String publicKeyFilePath) {
        this.publicKeyFilePath = publicKeyFilePath;
    }

    public String getPrivateKeyFilePath() {
        return privateKeyFilePath;
    }

    public void setPrivateKeyFilePath(String privateKeyFilePath) {
        this.privateKeyFilePath = privateKeyFilePath;
    }

    public String getReceivedSensitiveData() {
        return receivedSensitiveData;
    }

    public void setReceivedSensitiveData(String receivedSensitiveData) {
        this.receivedSensitiveData = receivedSensitiveData;
    }

    public String getNagadSignature() {
        return nagadSignature;
    }

    public void setNagadSignature(String nagadSignature) {
        this.nagadSignature = nagadSignature;
    }

    public String getSendingSensitiveData() {
        return sendingSensitiveData;
    }

    public void setSendingSensitiveData(String sendingSensitiveData) {
        this.sendingSensitiveData = sendingSensitiveData;
    }

    public String getOwnSignature() {
        return ownSignature;
    }

    public void setOwnSignature(String ownSignature) {
        this.ownSignature = ownSignature;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getSendingChallangeNO() {
        return sendingChallangeNO;
    }

    public void setSendingChallangeNO(String sendingChallangeNO) {
        this.sendingChallangeNO = sendingChallangeNO;
    }

    public String getReceivedChallangeNO() {
        return receivedChallangeNO;
    }

    public void setReceivedChallangeNO(String receivedChallangeNO) {
        this.receivedChallangeNO = receivedChallangeNO;
    }

    public String getPaymentReferanceID() {
        return paymentReferanceID;
    }

    public void setPaymentReferanceID(String paymentReferanceID) {
        this.paymentReferanceID = paymentReferanceID;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public NagadProcess initialize() throws Exception{
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String currentTime = sdf1.format(timestamp).toString();
        this.currentTime = currentTime;
        this.nagodOrderRequestResponse = this.nagadUtil.nagadInitilizeRequest(this.publicKeyFilePath,this.privateKeyFilePath,this.currentTime,this.marchentID,this.orderNo,this.sendingChallangeNO,this.ipV4,this.clientType,this.apiVersion,this.marchentAccountNo,this.nagadBaseURL);
        this.receivedSensitiveData = nagodOrderRequestResponse.getSensitiveData();
        this.nagadSignature = nagodOrderRequestResponse.getSignature();
        this.nagodOrderRequestResponseDecoded = nagadUtil.decodeSensitiveData(this.receivedSensitiveData,this.privateKeyFilePath);
        this.paymentReferanceID = nagodOrderRequestResponseDecoded.getPaymentReferenceId();
        this.receivedChallangeNO = nagodOrderRequestResponseDecoded.getChallenge();
        return  this;
    }

    public NagadProcess verify() throws Exception{
        this.isVerifiedSignature = this.nagadUtil.verifySignature(this.nagadSignature,this.publicKeyFilePath, this.receivedSensitiveData, this.privateKeyFilePath);
        return this;
    }

    public NagadProcess order() throws Exception{
        this.callbackResponseEntity = this.nagadUtil.getCallBackUrl(this.marchentID,this.orderNo,this.amount,this.currencyCode,this.receivedChallangeNO,this.marchentCallbackUrl,this.nagadBaseURL,this.ipV4,this.clientType,this.apiVersion,this.paymentReferanceID,this.publicKeyFilePath,this.privateKeyFilePath);
        this.nagadCallbackUrl = this.callbackResponseEntity.getCallBackUrl();

        return this;
    }

    public NagadProcess checkPaymentStatus(String paymentRefId){
        // todo:  code for check payment status; this.paymentStatus = .......
        return this;
    }
}
