package com.app.testapp.responseEntity.ssldto;

public class SSLCancelUrlDto {
    String status;
    String tran_id;
    String error;
    String bank_tran_id;
    String currency;
    String tran_date;
    String amount;
    String store_id;
    String currency_type;
    String currency_amount;
    String currency_rate;
    String base_fair;
    String value_a;
    String value_b;
    String value_c;
    String value_d;
    String verify_sign;
    String verify_sign_sha2;
    String verify_key;

    public SSLCancelUrlDto() {
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTran_id() {
        return tran_id;
    }

    public void setTran_id(String tran_id) {
        this.tran_id = tran_id;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getBank_tran_id() {
        return bank_tran_id;
    }

    public void setBank_tran_id(String bank_tran_id) {
        this.bank_tran_id = bank_tran_id;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getTran_date() {
        return tran_date;
    }

    public void setTran_date(String tran_date) {
        this.tran_date = tran_date;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getCurrency_type() {
        return currency_type;
    }

    public void setCurrency_type(String currency_type) {
        this.currency_type = currency_type;
    }

    public String getCurrency_amount() {
        return currency_amount;
    }

    public void setCurrency_amount(String currency_amount) {
        this.currency_amount = currency_amount;
    }

    public String getCurrency_rate() {
        return currency_rate;
    }

    public void setCurrency_rate(String currency_rate) {
        this.currency_rate = currency_rate;
    }

    public String getBase_fair() {
        return base_fair;
    }

    public void setBase_fair(String base_fair) {
        this.base_fair = base_fair;
    }

    public String getValue_a() {
        return value_a;
    }

    public void setValue_a(String value_a) {
        this.value_a = value_a;
    }

    public String getValue_b() {
        return value_b;
    }

    public void setValue_b(String value_b) {
        this.value_b = value_b;
    }

    public String getValue_c() {
        return value_c;
    }

    public void setValue_c(String value_c) {
        this.value_c = value_c;
    }

    public String getValue_d() {
        return value_d;
    }

    public void setValue_d(String value_d) {
        this.value_d = value_d;
    }

    public String getVerify_sign() {
        return verify_sign;
    }

    public void setVerify_sign(String verify_sign) {
        this.verify_sign = verify_sign;
    }

    public String getVerify_sign_sha2() {
        return verify_sign_sha2;
    }

    public void setVerify_sign_sha2(String verify_sign_sha2) {
        this.verify_sign_sha2 = verify_sign_sha2;
    }

    public String getVerify_key() {
        return verify_key;
    }

    public void setVerify_key(String verify_key) {
        this.verify_key = verify_key;
    }
}
