package com.app.testapp.utils;


public enum SSLURIs {

    INITIALIZE_URL("gwprocess/v4/api.php"),
    VALIDATION_URL("validator/api/merchantTransIDvalidationAPI.php")
;

    String uri;

    private   SSLURIs(String uri){
        this.uri = uri;
    }

    public String getUri() {
        return this.uri;
    }
}