package com.app.testapp.utils;

public enum NagadURIs {

    INITIALIZE_URL("api/dfs/check-out/initialize/"),
    ORDER_URL("api/dfs/check-out/complete/"),
    CHECK_PAYMENT_STATUS("/api/dfs/verify/payment/");

    String uri;

   private   NagadURIs(String uri){
        this.uri = uri;
    }

    public String getUri() {
        return this.uri;
    }
}
