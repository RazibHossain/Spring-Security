package com.app.testapp.responseEntity;



public class CallbackResponseEntity {


    String callBackUrl;
    String status;
    public CallbackResponseEntity() {
    }

    public CallbackResponseEntity(String callBackUrl, String status) {
        this.callBackUrl = callBackUrl;
        this.status = status;
    }

    public String getCallBackUrl() {
        return callBackUrl;
    }

    public void setCallBackUrl(String callBackUrl) {
        this.callBackUrl = callBackUrl;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
