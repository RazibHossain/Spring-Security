package com.app.testapp.controller.services;

import com.app.testapp.utils.SSLProcessBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class SSLGatewayComponent {
    @Value("${sslEcommerz.baseUrl}")
    private  String sslBaseUrl;

    @Bean
    SSLProcessBuilder getSSLProcessBuilder(){
        return new SSLProcessBuilder()
                .setSslBaseUrl(sslBaseUrl)
                .setCurrency("BDT")
                .setSuccess_url("http://192.168.100.151:8080/sslSuccess")
                .setFail_url("http://192.168.100.151:8080/sslFail")
                .setCancel_url("http://192.168.100.151:8080/sslCancel")
                .setIpn_url("http://192.168.100.151:8080/sslIPNListener")
                .setMulti_card_name("")
                .setAllowed_bin("")
                .setEmi_option("")
                .setEmi_max_inst_option("")
                .setEmi_selected_inst("")
                .setEmi_allow_only("")
                .setCus_name("student")
                .setCus_email("demomail.com")
                .setCus_add1("Netizen Bd")
                .setCus_add2("")
                .setCus_city("Mirpur")
                .setCus_state("")
                .setCus_postcode("1216")
                .setCus_country("Bangladesh")
                .setCus_phone("01010156400")
                .setCus_fax("")
                .setShipping_method("no")
                .setNum_of_item("")
                .setShip_name("")
                .setShip_add1("")
                .setShip_add2("")
                .setShip_city("")
                .setShip_state("")
                .setShip_postcode("")
                .setShip_country("")
                .setProduct_name("Payslip")
                .setProduct_category("fees")
                .setProduct_profile("Eduman")
                .setHours_till_departure("")
                .setFlight_type("")
                .setPnr("")
                .setJourney_from_to("")
                .setThird_party_booking("")
                .setHotel_name("")
                .setLength_of_stay("")
                .setCheck_in_time("")
                .setHotel_city("")
                .setProduct_type("")
                .setTopup_number("")
                .setCart("")
                .setProduct_amount("")
                .setVat("")
                .setDiscount_amount("")
                .setConvenience_fee("")
                .setValue_a("")
                .setValue_b("")
                .setValue_c("")
                .setValue_d("");




    }

}
