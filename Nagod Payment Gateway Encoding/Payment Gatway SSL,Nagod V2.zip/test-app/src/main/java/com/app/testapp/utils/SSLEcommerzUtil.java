package com.app.testapp.utils;

import com.app.testapp.responseEntity.SSLInitiatePaymentResponse;
import com.google.gson.Gson;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class SSLEcommerzUtil {

    public SSLInitiatePaymentResponse requestForSessionId(SSLProcess sslProcess) {

        String sslSessionIdUri = SSLURIs.INITIALIZE_URL.getUri();
        String url = sslProcess.getSslBaseUrl()+sslSessionIdUri;

        MultiValueMap<String, String> params= new LinkedMultiValueMap<String, String>();

        params.add("store_id", sslProcess.getStore_id());
        params.add("store_passwd", sslProcess.getStore_passwd());
        params.add("total_amount", sslProcess.getTotal_amount());
        params.add("currency", sslProcess.getCurrency());
        params.add("tran_id", sslProcess.getTran_id());
        params.add("success_url", sslProcess.getSuccess_url());
        params.add("fail_url", sslProcess.getFail_url());
        params.add("cancel_url", sslProcess.getCancel_url());
        params.add("ipn_url", sslProcess.getIpn_url());
        params.add("multi_card_name", sslProcess.getMulti_card_name());
        params.add("allowed_bin", sslProcess.getAllowed_bin());
        params.add("emi_option", sslProcess.getEmi_option());
        params.add("emi_max_inst_option", sslProcess.getEmi_max_inst_option());
        params.add("emi_selected_inst", sslProcess.getEmi_selected_inst());
        params.add("emi_allow_only", sslProcess.getEmi_allow_only());
        params.add("cus_name", sslProcess.getCus_name());
        params.add("cus_email", sslProcess.getCus_email());
        params.add("cus_add1", sslProcess.getCus_add1());
        params.add("cus_add2", sslProcess.getCus_add2());
        params.add("cus_city", sslProcess.getCus_city());
        params.add("cus_state", sslProcess.getCus_state());
        params.add("cus_postcode", sslProcess.getCus_postcode());
        params.add("cus_country", sslProcess.getCus_country());
        params.add("cus_phone", sslProcess.getCus_phone());
        params.add("cus_fax", sslProcess.getCus_fax());
        params.add("shipping_method", sslProcess.getShipping_method());
        params.add("num_of_item", sslProcess.getNum_of_item());
        params.add("ship_name", sslProcess.getShip_name());
        params.add("ship_add1", sslProcess.ship_add1);
        params.add("ship_add2", sslProcess.getShip_add2());
        params.add("ship_city", sslProcess.getShip_city());
        params.add("ship_state", sslProcess.getShip_state());
        params.add("ship_postcode", sslProcess.getShip_postcode());
        params.add("ship_country", sslProcess.getShip_country());
        params.add("product_name", sslProcess.getProduct_name());
        params.add("product_category", sslProcess.getProduct_category());
        params.add("product_profile", sslProcess.getProduct_profile());
        params.add("hours_till_departure", sslProcess.getHours_till_departure());
        params.add("flight_type", sslProcess.getFlight_type());
        params.add("pnr", sslProcess.getPnr());
        params.add("journey_from_to", sslProcess.getJourney_from_to());
        params.add("third_party_booking", sslProcess.getThird_party_booking());
        params.add("hotel_name", sslProcess.getHotel_name());
        params.add("length_of_stay", sslProcess.getLength_of_stay());
        params.add("check_in_time", sslProcess.getCheck_in_time());
        params.add("hotel_city", sslProcess.getHotel_city());
        params.add("product_type", sslProcess.getProduct_type());
        params.add("topup_number", sslProcess.getTopup_number());
        params.add("country_topup", sslProcess.getCountry_topup());
        params.add("cart", sslProcess.getCart());
        params.add("product_amount", sslProcess.getProduct_amount());
        params.add("vat", sslProcess.getVat());
        params.add("discount_amount", sslProcess.getDiscount_amount());
        params.add("convenience_fee", sslProcess.getConvenience_fee());
        params.add("value_a", sslProcess.getValue_a());
        params.add("value_b", sslProcess.getValue_b());
        params.add("value_c", sslProcess.getValue_c());
        params.add("value_d", sslProcess.getValue_d());

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(params, headers);

        ResponseEntity<String> response = restTemplate.postForEntity( url, request , String.class );
//        SSLInitiatePaymentResponse sslInitiatePaymentResponse = response.getBody();
        Gson gson = new Gson();
        SSLInitiatePaymentResponse sslInitiatePaymentResponse = gson.fromJson(response.getBody(), SSLInitiatePaymentResponse.class);
//        return sslInitiatePaymentResponse;
        return sslInitiatePaymentResponse;
    }
}
