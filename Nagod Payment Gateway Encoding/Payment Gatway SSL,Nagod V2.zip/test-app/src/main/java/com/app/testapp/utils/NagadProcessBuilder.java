package com.app.testapp.utils;

public class NagadProcessBuilder {

    String nagadBaseURL;
    String marchentCallbackUrl;
    String marchentID;
    String publicKeyFilePath;
    String privateKeyFilePath;
    String currencyCode;
    String marchentAccountNo;
    String ipV4;
    String apiVersion;
    String contentType;
    String clientType;

    public NagadProcessBuilder setNagadBaseURL(String nagadBaseURL) {
        this.nagadBaseURL = nagadBaseURL;
        return this; 
    }

    public NagadProcessBuilder setMarchentCallbackUrl(String marchentCallbackUrl) {
        this.marchentCallbackUrl = marchentCallbackUrl;
        return this;
    }



    public NagadProcessBuilder setMarchentID(String marchentID) {
        this.marchentID = marchentID;
        return this;
    }

    public NagadProcessBuilder setPublicKeyFilePath(String publicKeyFilePath) {
        this.publicKeyFilePath = publicKeyFilePath;
        return this;
    }

    public NagadProcessBuilder setPrivateKeyFilePath(String privateKeyFilePath) {
        this.privateKeyFilePath = privateKeyFilePath;
        return this;
    }



    public NagadProcessBuilder setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
        return this;
    }

    public NagadProcessBuilder setMarchentAccountNo(String marchentAccountNo) {
        this.marchentAccountNo = marchentAccountNo;
        return this;
    }

    public NagadProcessBuilder setIpV4(String ipV4) {
        this.ipV4 = ipV4;
        return this;
    }

    public NagadProcessBuilder setApiVersion(String apiVersion) {
        this.apiVersion = apiVersion;
        return this;
    }

    public NagadProcessBuilder setContentType(String contentType) {
        this.contentType = contentType;
        return this;
    }

    public NagadProcessBuilder setClientType(String clientType) {
        this.clientType = clientType;
        return this;
    }

    public NagadProcess build(){
        NagadProcess nagadProcess = new NagadProcess();
        nagadProcess.setIpV4(this.ipV4);
        nagadProcess.setApiVersion(this.apiVersion);
        nagadProcess.setContentType(this.contentType);
        nagadProcess.setClientType(this.clientType);
        nagadProcess.setMarchentAccountNo(this.marchentAccountNo);
        nagadProcess.setCurrencyCode(this.currencyCode);
        nagadProcess.setNagadBaseURL(this.nagadBaseURL);
        nagadProcess.setMarchentCallbackUrl(this.marchentCallbackUrl);
        nagadProcess.setMarchentID(this.marchentID);
        nagadProcess.setPublicKeyFilePath(this.publicKeyFilePath);
        nagadProcess.setPrivateKeyFilePath(this.privateKeyFilePath);

        return nagadProcess;
    }
 
    
}
