package com.app.testapp.controller.services;

import com.app.testapp.entity.SSLEcommerz;

import com.app.testapp.repository.SSLEcommerzRepository;
import com.app.testapp.responseEntity.*;
import com.app.testapp.utils.*;
import org.apache.tomcat.util.net.SSLUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

@Service
public class PaymentGatewayService {


    @Autowired
    NagadProcessBuilder nagadProcessBuilder;
    @Autowired
    SSLProcessBuilder sslProcessBuilder;
    @Autowired
    SSLEcommerzRepository sslEcommerzRepository;

    @Value("${sslEcommerz.baseUrl}")
    private String sslBaseUrl;
    public NagadProcess apiRequest(String paymentGateWay) throws Exception {

            NagadProcess nagadProcess = nagadProcessBuilder.build();
            nagadProcess.setAmount("110.20");
            nagadProcess.setOrderNo("6418745");
            nagadProcess.setSendingChallangeNO(getRandomHexString(40));

            nagadProcess.initialize()
                        .verify()
                        .order();
            return nagadProcess;
        }


        public Object bkashApiRequest(){


        return null;
        }

    public SSLProcess sslApiRequest() throws Exception{
        SSLProcess sslProcess = sslProcessBuilder.build();

        sslProcess.setStore_id("testbox");
        sslProcess.setStore_passwd("qwerty");
        sslProcess.setTotal_amount("110");
        sslProcess.setTran_id("123454465656565");

        sslProcess.initialize();

        if(sslProcess.getSslInitiatePaymentResponse().getStatus().equals("SUCCESS")){
            SSLEcommerz sslEcommerz = new SSLEcommerz();
            sslEcommerz.setAmount(Double.parseDouble(sslProcess.getTotal_amount()));
            sslEcommerz.setPaymentUpdateStatus(0);
            sslEcommerz.setPayslip_transId(sslProcess.getTran_id());
            sslEcommerz.setSessionKey(sslProcess.getSslInitiatePaymentResponse().getSessionkey());
            sslEcommerz.setInstitueId(1234);
            sslEcommerz.setMerchantName("Mamun");
            sslEcommerz.setStudentId("Stu-1234");
            sslEcommerz.setPaymentRequestedDateTime(new Date());
            sslEcommerzRepository.saveAndFlush(sslEcommerz);
        }



        return sslProcess;
    }

//    public SSLInitiatePaymentResponse sslApiRequest() {
//        SSLEcommerzUtil sslEcommerzUtil = new SSLEcommerzUtil();
//       SSLInitiatePaymentResponse sslInitiatePaymentResponse = sslEcommerzUtil.requestForSessionId();
//        return sslInitiatePaymentResponse;
//    }



      String getRandomHexString(int numchars){
        Random r = new Random();
        StringBuffer sb = new StringBuffer();
        while(sb.length() < numchars){
            sb.append(Integer.toHexString(r.nextInt()));
        }

        return sb.toString().substring(0, numchars);
    }


    public Object sslCheckTransactionByTranId() {

        String tran_id="12345";
        String store_id="testbox";
        String store_passwd="qwerty";

        String url = "https://sandbox.sslcommerz.com/validator/api/merchantTransIDvalidationAPI.php?tran_id="+tran_id+"&store_id="+store_id+"&store_passwd="+store_passwd+"";

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<Object> response = restTemplate.getForEntity( url , Object.class );

        return response;
    }

    @Transactional
    public void sslCheckTransactionBysessionkey(List<SSLEcommerz> sslEcommerzList) {

        for(SSLEcommerz sslEcommerzs: sslEcommerzList ){
            int institueId = sslEcommerzs.getInstitueId();
//            String store_id= getStoreIdByInstitueId(institueId);
//            String store_passwd= getStorePasswordByInstitueId(institueId);
            String store_id="testbox";
            String store_passwd="qwerty";
            String sessionKey = sslEcommerzs.getSessionKey();
            String validationUri = SSLURIs.VALIDATION_URL.getUri();
            String url = sslBaseUrl + validationUri + "?sessionkey="+sessionKey+"&store_id="+store_id+"&store_passwd="+store_passwd+"";
            RestTemplate restTemplate = new RestTemplate();

            ResponseEntity<SSLCheckTransactionBySessionResponse> response = restTemplate.getForEntity( url , SSLCheckTransactionBySessionResponse.class );
            SSLCheckTransactionBySessionResponse sslCheckTransactionBySessionResponse = response.getBody();

            if(sslCheckTransactionBySessionResponse.getStatus().equals("VALID")){
//                update TransactionHistroyTable of payment status
                sslEcommerzRepository.updatePaymentStatus(new Date(),sessionKey);

//          updateStudentInvoicess according transaction history
            }

        }

    }
}