package com.app.testapp.utils;

public class SSLProcessBuilder {
    
    String sslBaseUrl;
    String currency;
    String success_url;
    String fail_url;
    String cancel_url;
    String ipn_url;
    String multi_card_name;
    String allowed_bin;
    String emi_option;
    String emi_max_inst_option;
    String emi_selected_inst;
    String emi_allow_only;
    String cus_name;
    String cus_email;
    String cus_add1;
    String cus_add2;
    String cus_city;
    String cus_state;
    String cus_postcode;
    String cus_country;
    String cus_phone;
    String cus_fax;
    String shipping_method;
    String num_of_item;
    String ship_name;
    String ship_add1;
    String ship_add2;
    String ship_city;
    String ship_state;
    String ship_postcode;
    String ship_country;
    String product_name;
    String product_category;
    String product_profile;
    String hours_till_departure;
    String flight_type;
    String pnr;
    String journey_from_to;
    String third_party_booking;
    String hotel_name;
    String length_of_stay;
    String check_in_time;
    String hotel_city;
    String product_type;
    String topup_number;
    String country_topup;
    String cart;
    String product_amount;
    String vat;
    String discount_amount;
    String convenience_fee;
    String value_a;
    String value_b;
    String value_c;
    String value_d;

    public SSLProcessBuilder setSslBaseUrl(String sslBaseUrl) {
        this.sslBaseUrl = sslBaseUrl;
        return this;
    }
    

    public SSLProcessBuilder setCurrency(String currency) {
        this.currency = currency;
        return this;
    }

    public SSLProcessBuilder setSuccess_url(String success_url) {
        this.success_url = success_url;
        return this;
    }

    public SSLProcessBuilder setFail_url(String fail_url) {
        this.fail_url = fail_url;
        return this;
    }

    public SSLProcessBuilder setCancel_url(String cancel_url) {
        this.cancel_url = cancel_url;
        return this;
    }

    public SSLProcessBuilder setIpn_url(String ipn_url) {
        this.ipn_url = ipn_url;
        return this;
    }

    public SSLProcessBuilder setCus_name(String cus_name) {
        this.cus_name = cus_name;
        return this;
    }

    public SSLProcessBuilder setCus_email(String cus_email) {
        this.cus_email = cus_email;
        return this;
    }

    public SSLProcessBuilder setCus_add1(String cus_add1) {
        this.cus_add1 = cus_add1;
        return this;
    }

    public SSLProcessBuilder setCus_city(String cus_city) {
        this.cus_city = cus_city;
        return this;
    }

    public SSLProcessBuilder setCus_postcode(String cus_postcode) {
        this.cus_postcode = cus_postcode;
        return this;
    }

    public SSLProcessBuilder setCus_country(String cus_country) {
        this.cus_country = cus_country;
        return this;
    }

    public SSLProcessBuilder setCus_phone(String cus_phone) {
        this.cus_phone = cus_phone;
        return this;
    }

    public SSLProcessBuilder setShipping_method(String shipping_method) {
        this.shipping_method = shipping_method;
        return this;
    }

    public SSLProcessBuilder setProduct_name(String product_name) {
        this.product_name = product_name;
        return this;
    }

    public SSLProcessBuilder setProduct_category(String product_category) {
        this.product_category = product_category;
        return this;
    }

    public SSLProcessBuilder setProduct_profile(String product_profile) {
        this.product_profile = product_profile;
        return this;
    }

    public SSLProcessBuilder setMulti_card_name(String multi_card_name) {
        this.multi_card_name = multi_card_name;
        return this;
    }

    public SSLProcessBuilder setAllowed_bin(String allowed_bin) {
        this.allowed_bin = allowed_bin;
        return this;
    }

    public SSLProcessBuilder setEmi_option(String emi_option) {
        this.emi_option = emi_option;
        return this;
    }

    public SSLProcessBuilder setEmi_max_inst_option(String emi_max_inst_option) {
        this.emi_max_inst_option = emi_max_inst_option;
        return this;
    }

    public SSLProcessBuilder setEmi_selected_inst(String emi_selected_inst) {
        this.emi_selected_inst = emi_selected_inst;
        return this;
    }

    public SSLProcessBuilder setEmi_allow_only(String emi_allow_only) {
        this.emi_allow_only = emi_allow_only;
        return this;
    }

    public SSLProcessBuilder setCus_add2(String cus_add2) {
        this.cus_add2 = cus_add2;
        return this;
    }

    public SSLProcessBuilder setCus_state(String cus_state) {
        this.cus_state = cus_state;
        return this;
    }

    public SSLProcessBuilder setCus_fax(String cus_fax) {
        this.cus_fax = cus_fax;
        return this;
    }

    public SSLProcessBuilder setNum_of_item(String num_of_item) {
        this.num_of_item = num_of_item;
        return this;
    }

    public SSLProcessBuilder setShip_name(String ship_name) {
        this.ship_name = ship_name;
        return this;
    }

    public SSLProcessBuilder setShip_add1(String ship_add1) {
        this.ship_add1 = ship_add1;
        return this;
    }

    public SSLProcessBuilder setShip_add2(String ship_add2) {
        this.ship_add2 = ship_add2;
        return this;
    }

    public SSLProcessBuilder setShip_city(String ship_city) {
        this.ship_city = ship_city;
        return this;
    }

    public SSLProcessBuilder setShip_state(String ship_state) {
        this.ship_state = ship_state;
        return this;
    }

    public SSLProcessBuilder setShip_postcode(String ship_postcode) {
        this.ship_postcode = ship_postcode;
        return this;
    }

    public SSLProcessBuilder setShip_country(String ship_country) {
        this.ship_country = ship_country;
        return this;
    }

    public SSLProcessBuilder setHours_till_departure(String hours_till_departure) {
        this.hours_till_departure = hours_till_departure;
        return this;
    }

    public SSLProcessBuilder setFlight_type(String flight_type) {
        this.flight_type = flight_type;
        return this;
    }

    public SSLProcessBuilder setPnr(String pnr) {
        this.pnr = pnr;
        return this;
    }

    public SSLProcessBuilder setJourney_from_to(String journey_from_to) {
        this.journey_from_to = journey_from_to;
        return this;
    }

    public SSLProcessBuilder setThird_party_booking(String third_party_booking) {
        this.third_party_booking = third_party_booking;
        return this;
    }

    public SSLProcessBuilder setHotel_name(String hotel_name) {
        this.hotel_name = hotel_name;
        return this;
    }

    public SSLProcessBuilder setLength_of_stay(String length_of_stay) {
        this.length_of_stay = length_of_stay;
        return this;
    }

    public SSLProcessBuilder setCheck_in_time(String check_in_time) {
        this.check_in_time = check_in_time;
        return this;
    }

    public SSLProcessBuilder setHotel_city(String hotel_city) {
        this.hotel_city = hotel_city;
        return this;
    }

    public SSLProcessBuilder setProduct_type(String product_type) {
        this.product_type = product_type;
        return this;
    }

    public SSLProcessBuilder setTopup_number(String topup_number) {
        this.topup_number = topup_number;
        return this;
    }

    public SSLProcessBuilder setCountry_topup(String country_topup) {
        this.country_topup = country_topup;
        return this;
    }

    public SSLProcessBuilder setCart(String cart) {
        this.cart = cart;
        return this;
    }

    public SSLProcessBuilder setProduct_amount(String product_amount) {
        this.product_amount = product_amount;
        return this;
    }

    public SSLProcessBuilder setVat(String vat) {
        this.vat = vat;
        return this;
    }

    public SSLProcessBuilder setDiscount_amount(String discount_amount) {
        this.discount_amount = discount_amount;
        return this;
    }

    public SSLProcessBuilder setConvenience_fee(String convenience_fee) {
        this.convenience_fee = convenience_fee;
        return this;
    }

    public SSLProcessBuilder setValue_a(String value_a) {
        this.value_a = value_a;
        return this;
    }

    public SSLProcessBuilder setValue_b(String value_b) {
        this.value_b = value_b;
        return this;
    }

    public SSLProcessBuilder setValue_c(String value_c) {
        this.value_c = value_c;
        return this;
    }

    public SSLProcessBuilder setValue_d(String value_d) {
        this.value_d = value_d;
        return this;
    }

    public SSLProcess build(){
        SSLProcess sslProcess = new SSLProcess();
        sslProcess.setSslBaseUrl(this.sslBaseUrl);
        sslProcess.setCurrency(this.currency);
        sslProcess.setSuccess_url(this.success_url);
        sslProcess.setFail_url(this.fail_url);
        sslProcess.setCancel_url(this.cancel_url);
        sslProcess.setIpn_url(this.ipn_url);
        sslProcess.setCus_name(this.cus_name);
        sslProcess.setCus_email(this.cus_email);
        sslProcess.setCus_add1(this.cus_add1);
        sslProcess.setCus_add2(this.cus_add2);
        sslProcess.setCus_city(this.cus_city);
        sslProcess.setCus_state(this.cus_state);
        sslProcess.setCus_postcode(this.cus_postcode);
        sslProcess.setCus_country(this.cus_country);
        sslProcess.setCus_phone(this.cus_phone);
        sslProcess.setCus_fax(this.cus_fax);
        sslProcess.setShipping_method(this.shipping_method);
        sslProcess.setProduct_name(this.product_name);
        sslProcess.setProduct_category(this.product_category);
        sslProcess.setProduct_profile(this.product_profile);
        sslProcess.setMulti_card_name(this.multi_card_name);
        sslProcess.setAllowed_bin(this.allowed_bin);
        sslProcess.setEmi_option(this.emi_option);
        sslProcess.setEmi_max_inst_option(this.emi_max_inst_option);
        sslProcess.setEmi_selected_inst(this.emi_selected_inst);
        sslProcess.setEmi_allow_only(this.emi_allow_only);
        sslProcess.setNum_of_item(this.num_of_item);
        sslProcess.setShip_name(this.ship_name);
        sslProcess.setShip_add1(this.ship_add1);
        sslProcess.setShip_add2(this.ship_add2);
        sslProcess.setShip_city(this.ship_city);
        sslProcess.setShip_state(this.ship_state);
        sslProcess.setShip_postcode(this.ship_postcode);
        sslProcess.setShip_country(this.ship_country);
        sslProcess.setHours_till_departure(this.hours_till_departure);
        sslProcess.setFlight_type(this.flight_type);
        sslProcess.setPnr(this.pnr);
        sslProcess.setJourney_from_to(this.journey_from_to);
        sslProcess.setThird_party_booking(this.third_party_booking);
        sslProcess.setHotel_name(this.hotel_name);
        sslProcess.setLength_of_stay(this.length_of_stay);
        sslProcess.setCheck_in_time(this.check_in_time);
        sslProcess.setHotel_city(this.hotel_city);
        sslProcess.setProduct_type(this.product_type);
        sslProcess.setTopup_number(this.topup_number);
        sslProcess.setCart(this.cart);
        sslProcess.setProduct_amount(this.product_amount);
        sslProcess.setVat(this.vat);
        sslProcess.setDiscount_amount(this.discount_amount);
        sslProcess.setConvenience_fee(this.convenience_fee);
        sslProcess.setValue_a(this.value_a);
        sslProcess.setValue_b(this.value_b);
        sslProcess.setValue_c(this.value_c);
        sslProcess.setValue_d(this.value_d);

        return sslProcess;
    }

}
