package com.app.testapp.controller;

import javax.crypto.Cipher;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Base64;

public class Rsa {

    static String getEncodedByPublicKey(String secretMessage, String pulickKeyFilePath) throws Exception{
        File publicKeyFile = new File(pulickKeyFilePath);
        byte[] publicKeyBytes = Files.readAllBytes(publicKeyFile.toPath());
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyBytes));
        PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);


        Cipher encryptCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        encryptCipher.init(Cipher.ENCRYPT_MODE, publicKey);

        byte[] secretMessageBytes = secretMessage.getBytes(StandardCharsets.UTF_8);
        byte[] encryptedMessageBytes = encryptCipher.doFinal(secretMessageBytes);

        String encodedMessage = Base64.getEncoder().encodeToString(encryptedMessageBytes);

        return encodedMessage;
    }


    public static String getEncodedByPrivateKey(String secretMessage, String privateKeyFilePath) throws Exception{

        File privateKeyFile = new File(privateKeyFilePath);
        byte[] privateKeyBytes = Files.readAllBytes(privateKeyFile.toPath());
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyBytes));

        PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageHash = md.digest(secretMessage.getBytes(StandardCharsets.UTF_8));

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);
        byte[] digitalSignature = cipher.doFinal(messageHash);

        String encodedMessage = Base64.getEncoder().encodeToString(digitalSignature);

        return encodedMessage;
    }

//    public static void main(String[] args) throws Exception {
//
//        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
//        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//
//        String currentTime = sdf1.format(timestamp).toString();         // 202
//
//
//        String publicKeyFilePath = "C:\\Users\\Dell\\Downloads\\Encription\\keys\\pgPublicKey.txt";
//        String privateKeyFilePath = "C:\\Users\\Dell\\Downloads\\Encription\\keys\\merchantPrivateKey.txt";
//
//
//        String secretMessage = "{\n" +
//                "  \"merchantId\": \"683002007104225\",\n" +
//                "  \"datetime\": \"+20220328131507+\",\n" +
//                "  \"orderId\": \"12345\",\n" +
//                "  \"challenge\":\"695EF3869547B6C07F5D56399935FB72D21737EA\"\n" +
//                "}";
//
//
//        System.out.println(getEncodedByPublicKey(secretMessage, publicKeyFilePath));
//        System.out.println(getEncodedByPrivateKey(secretMessage, privateKeyFilePath));
//
//
//
//
//
//    }
}
