insert into utility(utility_id,utility_name) values(1,'Laptop');
insert into utility(utility_id,utility_name) values(2,'Mobile');
insert into utility(utility_id,utility_name) values(3,'Headset');
insert into utility(utility_id,utility_name) values(4,'TV');