package com.example.ZuulClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
